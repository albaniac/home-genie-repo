# Welcome to the Homegenie Package Repository

A collection of user-contributed Automation Programs, Widgets and MIG Interfaces for extending HomeGenie functionalities.

## Contributing

If you created some useful programs/widgets/interfaces that you would like to share, read about how to
<a href="https://github.com/genielabs/homegenie-packages" target="_blank">contribute to this repository</a>.

