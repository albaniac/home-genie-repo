# jkUtils - Solar Altitude

Calculates schedulers for sunrise/sunset with civil, nautical, astronomical timings.



