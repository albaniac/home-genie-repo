# Earth Tools

Gathers from <a href="http://www.earthtools.org/" target="_blank">Earth Tools</a> service all data about sun rise/set. 

It can be used for "Sunrise/Sunset" scheduling.


