# TimeTable Widget

Widget for scheduling thermostats, lights and shutters.



