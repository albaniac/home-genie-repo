# Turn Off Delay

When device is turned on, automatically turn it off after a given delay.



