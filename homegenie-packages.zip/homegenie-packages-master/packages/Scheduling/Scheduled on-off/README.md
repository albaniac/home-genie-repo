# Scheduled ON/OFF

Turn on/off a device using HG scheduler.



