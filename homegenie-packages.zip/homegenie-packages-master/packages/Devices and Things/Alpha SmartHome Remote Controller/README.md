# Alpha Smart Home Remote Controller

This is a simple program to control 8 relays TCP/IP Network module. You must only configure the Network Relay IP address and the communication port.

<a href="http://www.alphachn.com/products.asp?id=134" target="_blank">Product Page</a>


