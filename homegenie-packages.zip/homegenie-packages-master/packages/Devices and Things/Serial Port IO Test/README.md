# Serial Port I/O

Serial Port I/O communication example.


