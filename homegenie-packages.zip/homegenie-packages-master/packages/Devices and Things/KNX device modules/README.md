# KNX modules

Adds 5 virtual modules. KNX address of each device can be configured from the module options popup.


