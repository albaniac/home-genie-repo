# WeMo Wi-Fi Plug

This WeMo app permit to control the belkin wifi plug like <a href="http://www.belkin.com/us/p/P-F7C027/" target="_blank">this one</a>.

That permit to, on a simple widget on HomeGenie : 

 * Have a status of the plug : on ? off ? 
 * Switch on or off

## Setup

    IP Address of the plug
    Time in second between loop to update the status (60 seconds on my side)
    Switch off/on when alarm is arm/disarm


