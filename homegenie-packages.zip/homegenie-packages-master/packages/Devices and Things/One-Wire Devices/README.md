# One-Wire Modules

Integrates 1-wire devices as HG modules (Linux only).

To enable a 1-wire device, its ID must be specified in the module options popup.

To find out your connected devices ID, issue from a terminal the command:

    ls -la /sys/bus/w1/devices/
