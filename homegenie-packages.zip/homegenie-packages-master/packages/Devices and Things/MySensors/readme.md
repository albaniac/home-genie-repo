MySensors Gateway. (Supports both Serial and Ethernet Gateways)

See https://www.mysensors.org/ for more information.

Created initialy by mvdarend
