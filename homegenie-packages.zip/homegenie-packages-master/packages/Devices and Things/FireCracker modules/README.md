# X10 Firecracker Modules

FireCracker driver with X10 virtual modules.

## Instructions

This program requires `python-serial`:

    sudo apt-get install python-serial


