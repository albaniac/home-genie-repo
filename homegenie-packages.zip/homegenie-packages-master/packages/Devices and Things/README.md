# Devices and Things

This folder contains packages related to the integration of various devices and services.
