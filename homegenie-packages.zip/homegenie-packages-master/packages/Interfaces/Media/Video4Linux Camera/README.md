# Video4Linux camera driver

Interface driver for V4L compatible cameras. Tested on Ubuntu 64bit and Raspberry Pi.

