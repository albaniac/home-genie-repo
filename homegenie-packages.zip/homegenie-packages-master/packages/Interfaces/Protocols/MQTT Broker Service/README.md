# MQTT Broker Service

MQTT Broker Service for HomeGenie. Listening on default port 1883.
It can also be used as MQTT server endpoint for HomeGenie interconnections.
Once installed, enable it from the **Settings** page.

Based on <a href="https://github.com/ppatierno/gnatmq" target="_blank">GnatMq</a>.

