# MIG-WeecoBoard

HomeGenie / MIG interface driver for Weeco 4M board
