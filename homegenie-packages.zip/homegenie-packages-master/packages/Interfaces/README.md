# MIG - Interfaces

This folder contains packages related to MIG inteface drivers for HomeGenie.
