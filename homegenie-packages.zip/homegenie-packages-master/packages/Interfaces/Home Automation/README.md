# MIG - Home Automation

Home Automation protocols and hardware drivers.
