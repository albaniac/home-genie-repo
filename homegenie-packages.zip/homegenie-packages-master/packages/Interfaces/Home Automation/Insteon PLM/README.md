# Insteon PLM interface driver

Insteon PLM driver for SmartHome 2413S/2413U.

<a href="http://www.smarthome.com/powerlinc-modem-insteon-2413s-serial-interface-dual-band.html" target="_blank">SmartHome 2413S Product Page</a>

<a href="http://www.smarthome.com/powerlinc-modem-insteon-2413u-usb-interface-dual-band.html" target="_blank">SmartHome 2413U Product Page</a>

