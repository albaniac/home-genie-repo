# Ping Me at Home

Simulate presence in the house by looping a scenario within a given interval of time.

The scenario to run can be any automation program such as a pre-recorded <a href="http://www.homegenie.it/docs/scenarios.php" target="_blank">Wizard Script</a>.


