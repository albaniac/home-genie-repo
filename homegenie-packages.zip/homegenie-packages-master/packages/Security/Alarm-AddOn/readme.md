Manage the events regardless of the "90-Security" script built in HomeGenie, around alarm : activated / deactivated / triggered. And doing some severals actions :

    Send SMS
    Alert on the karotz (under openkarotz)
    Switch off the light
    Move the shutter
    Activate the webcam detection on "Synology Surveillance Station"

More description here : http://www.homegenie.it/forum/index.php?topic=520.0 http://www.homegenie.it/forum/index.php?topic=6.0
