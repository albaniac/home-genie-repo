Permit to check two zwave device and alerte in case of Jam the zwave network.

More description here : http://www.homegenie.it/forum/index.php?topic=1015.0
