# Ping Me at Home

When security system is armed, pings your mobile device to determine when you're getting close to home.

The program exposes the event **PingMe.AtHome**, that can be used both in Wizard Scripts or C# APPs to trigger actions when you get home.


