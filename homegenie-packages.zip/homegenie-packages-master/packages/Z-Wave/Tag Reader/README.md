# Tag Reader

Example program for the BeNext Tag reader.

This program allows to save tag IDs and remove them.

The event **TagReader.Alarm** is sent when a tag is recognized.


