# Fibaro RGBWM-441

Adds ZWave Fibaro RGBWM-441 control capability to HomeGenie.
