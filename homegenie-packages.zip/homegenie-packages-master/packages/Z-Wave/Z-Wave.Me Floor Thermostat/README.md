# Z-Wave.Me Thermostat

Widget for controlling Z-Wave.Me thermostat.
