# Z-Wave

This folder contains packages related to Z-Wave devices and functionalities.
