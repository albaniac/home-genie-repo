# Alcatel One Touch Y800Z

Control and automate Alcatel One Touch Y800Z.

It also add feature for sending SMS notifies when a device status changes and/or when the Security Alarm System is triggered.


