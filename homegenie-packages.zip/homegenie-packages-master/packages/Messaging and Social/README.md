# Messaging and Social

This folder contains packages related to the integration of messaging/notification services and devices.
