![Pushsafer](https://www.pushsafer.com/de/assets/logos/logo.png)

Send [pushsafer.com](https://www.pushsafer.com) notifications by HomeGenie

Pushsafer make it easy and safe to get push-notifications in real time on your
- Android device
- iOS device (incl. iPhone, iPad, iPod Touch)
- Windows 10 Phone & Desktop
- Browser (Chrome & Firefox)

# Usage
Create a Pushsafer.com [Account](https://www.pushsafer.com), register your devices with our [Client Apps](https://www.pushsafer.com/en/apps).
In HomeGenie you have to enter your Private or Alias Key for receiving push notifications.
