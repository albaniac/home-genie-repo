

Evolution of the native smart light script :

    Start timeout after motion goes off (not after first on, because my light goes off is i stay in movement too much time)
    Light goes on if luminance become under the trigger luminance, even if there is already "move"
    Add luminance trigger in the "smart device" instead a value in a script
    Add a customize field to pause loop which turn off
    Add a virtual switch : to enable/disable easily this script (go to manual mode ;))

    Add an "offset" : in case of the luminance raise by the controled light (that permit to avoid on-off-on-off-on), in my case, i adjust tha value to the difference : luminance with light on - luminance with light off

    More details here : http://www.homegenie.it/forum/index.php?topic=845.0

