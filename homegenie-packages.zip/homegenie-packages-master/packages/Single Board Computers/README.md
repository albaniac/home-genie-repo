# Single Board Computer

Collection of useful packages when running HomeGenie on a Single Board Computer based on Debial Linux.


