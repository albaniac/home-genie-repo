# DHT-11 Sensor Module

Temperature and Humidity sensing using DHT-11 with data pin on GPIO#23. 

**Edit program code line #1 to change the data pin GPIO.**

## Videos

<a href="https://www.youtube.com/watch?v=Q0KtT9Lo6Ro" target="_blank">Eden Board Recipe #3: DHT-11 Temperature and Humidity Sensor</a>


