# Grove Led Bar

Example for controlling a Grove Led Bar.

<a href="http://www.seeedstudio.com/wiki/Grove_-_LED_Bar" target="_blank">Product Site</a>

## Videos

<a href="https://www.youtube.com/watch?v=JbFSiN3H2ig" target="_blank">Eden Board Recipe #2: Grove Led Bar</a>


