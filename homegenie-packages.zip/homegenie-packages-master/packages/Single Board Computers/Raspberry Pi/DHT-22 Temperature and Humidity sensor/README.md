# DHT-22 Sensor Module

Temperature and Humidity sensing using DHT-22 with data pin on GPIO#4. 

**Edit program code line #1 to change the data pin GPIO.**
