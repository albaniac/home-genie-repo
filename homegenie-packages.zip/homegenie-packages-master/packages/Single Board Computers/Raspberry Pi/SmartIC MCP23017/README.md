# SmartIC MCP23017

Using 2 MCP23017 I/O expanders connected to 0x20 and 0x21 I2C bus. 


