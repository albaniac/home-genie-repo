# Eden Board V2

http://www.homegenie.it/docs/diy/eden_v2.php
