# MCP23017 GPIO Modules

MCP23017 expander GPIO mapped to HG modules.

By default, pins A0-A7 are mapped as output modules (switch) and B0-B7 as input modules (sensor).

To change this configuration, edit the program source code.

For wirings see <a href="http://www.skpang.co.uk/blog/archives/454" target="_blank">this link</a>.


