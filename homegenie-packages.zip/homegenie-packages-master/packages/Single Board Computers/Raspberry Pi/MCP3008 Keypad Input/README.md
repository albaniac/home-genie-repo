# MCP3008 Keypad Input

Using a 3x4 numeric keypad module connected to one MCP3008 analog channel.

Based on <a href="http://www.instructables.com/id/Arduino-3-wire-Matrix-Keypad/" target="_blank">Instructables Example</a>.


