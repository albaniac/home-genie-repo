# Eden Board V1 Keypad Menu

Implement a settings menu for Eden Oled Display package controlled by a 3x4 numeric keypad.

## Package Dependencies

- Eden Board V1 Display
- MCP3008 Keypad Input

<a href="http://www.homegenie.it/docs/diy/eden.php" target="_blank">Project Page</a>



