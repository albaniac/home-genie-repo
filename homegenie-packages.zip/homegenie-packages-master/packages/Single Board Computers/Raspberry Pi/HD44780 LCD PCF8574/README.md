# HD44780 LCD PCF8574

Example of using HD44780 LCD display with PCF8574 I2C I/O expander.


