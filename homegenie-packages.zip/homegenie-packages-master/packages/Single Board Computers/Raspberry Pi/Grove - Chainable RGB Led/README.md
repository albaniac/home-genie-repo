# Grove Chainable RGB Led

Module for controlling Chainable RGB color leds modules wired to GPIO#4 and GPIO#21/27 (power with 3v3).

<a href="http://www.seeedstudio.com/wiki/Grove_-_Chainable_RGB_LED" target="_blank">Product Site</a>

## Videos

<a href="https://www.youtube.com/watch?v=an5XDQ5dFLI" target="_blank">Eden Board Recipe #1: Grove Chainable RGB Led</a>

<a href="https://www.youtube.com/watch?v=qRUlqEmEm2c" target="_blank">HomeGenie: Grove Relay + RGB Led</a>


