# SSD1306 OLED display

Display driver for controlling I2C Ssd 1306 (128x64) Oled display.

<a href="http://www.homegenie.it/docs/diy/eden.php#edenoled" target="_blank">Example Project</a>

## Videos

<a href="https://www.youtube.com/watch?v=8tsISYytX1Y" target="_blank">HomeGenie - Raspberry Pi - How to setup Ssd1306 oled display with an interactive menu</a>


